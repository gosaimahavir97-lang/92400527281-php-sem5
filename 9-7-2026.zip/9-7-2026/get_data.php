<?php
// Debugging Data
echo "<pre>";
//print_r($_GET);
print_r($_POST);
echo "</pre>";

//$user_name= $_POST;
//$user_username= $_POST;

//echo $user_name;
    ?>