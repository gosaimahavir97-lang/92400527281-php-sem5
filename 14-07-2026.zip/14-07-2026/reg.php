<?php
//Debugging Data
echo "<pre>";
print_r($_FILES);
  echo "</pre>";          

$target_path = "uploads/"; //Location for uploadind files
$target_path = $target_path.basename( $_FILES['fileToUpload']['name']);
// uploads/filename.jpg
if(move_uploaded_file($_FILES['fileToUpload']['tmp_name'], $target_path)) {

echo "File uploaded successfully!";

} else{

echo "Sorry, file not uploaded, please try again!";

}

?>