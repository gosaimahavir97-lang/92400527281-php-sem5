<!DOCTYPE html>
<html lang='en'>
<head>
    <meta charset='utf-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1'>
    <title>Document</title>
</head>
<body>
    <form action="login_auth.php" method="post">
        <input type="text" name="user" placeholder="Username" >
        <input type="text" name="pass" placeholder="Password">
        <input type="submit" value="Login">
        </form>
</body>
</html>