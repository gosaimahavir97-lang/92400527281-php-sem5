<?php 
echo"welcome user";
?>