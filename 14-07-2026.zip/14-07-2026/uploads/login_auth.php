<?php
//Debugging Data
echo "<pre>";
print_r($_POST);
echo "</pre>";

$user = $_POST['user'];
$pass = $_POST['pass'];

if($user == "Admin" && $pass == "Gosai") {
    //echo "Welcome Admin";
   header("location: dashboard.php");
}else{


    echo "Wrong username or password";
}
?>