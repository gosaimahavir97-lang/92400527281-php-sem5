<?php
function encrypt_cookie($user_value)
{
setcookie("user", "Mahavir", time() + 300);
}
?>